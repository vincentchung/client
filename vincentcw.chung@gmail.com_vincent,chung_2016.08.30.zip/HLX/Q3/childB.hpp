//
//  childB.hpp
//  Multi-process
//
//  Created by 鐘淳文 on 2016/8/29.
//  Copyright © 2016年 vincent. All rights reserved.
//

#ifndef childB_h
#define childB_h

#define SHM_NUM_LIMIT 64

void processB(int shm_array_id);

#endif /* childB_h */
