//
//  childA.hpp
//  Multi-process
//
//  Created by 鐘淳文 on 2016/8/29.
//  Copyright © 2016年 vincent. All rights reserved.
//

#ifndef childA_hpp
#define childA_hpp

#include <stdio.h>
void processA(int parent_to_child);
#endif /* childA_hpp */
